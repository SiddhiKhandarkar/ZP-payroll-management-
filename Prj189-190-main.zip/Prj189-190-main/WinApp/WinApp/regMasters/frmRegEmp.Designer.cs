﻿namespace WinApp.regMasters
{
    partial class frmRegEmp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btn_regEmployee = new System.Windows.Forms.Button();
            this.cmb_empSpouseName = new System.Windows.Forms.ComboBox();
            this.cmb_empSpouseWorkStatus = new System.Windows.Forms.ComboBox();
            this.cmb_empJoiningCategory = new System.Windows.Forms.ComboBox();
            this.cmb_empCategory = new System.Windows.Forms.ComboBox();
            this.cmb_empOfficeType = new System.Windows.Forms.ComboBox();
            this.txt_empEducation = new System.Windows.Forms.TextBox();
            this.dtp_empDOJ = new System.Windows.Forms.DateTimePicker();
            this.dtp_empDOB = new System.Windows.Forms.DateTimePicker();
            this.cmb_empGender = new System.Windows.Forms.ComboBox();
            this.txt_empAddress = new System.Windows.Forms.TextBox();
            this.txt_empContactNo = new System.Windows.Forms.TextBox();
            this.txt_empMailId = new System.Windows.Forms.TextBox();
            this.txt_empGovtId = new System.Windows.Forms.TextBox();
            this.txt_empName = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btn_regEmployee);
            this.groupBox1.Controls.Add(this.cmb_empSpouseName);
            this.groupBox1.Controls.Add(this.cmb_empSpouseWorkStatus);
            this.groupBox1.Controls.Add(this.cmb_empJoiningCategory);
            this.groupBox1.Controls.Add(this.cmb_empCategory);
            this.groupBox1.Controls.Add(this.cmb_empOfficeType);
            this.groupBox1.Controls.Add(this.txt_empEducation);
            this.groupBox1.Controls.Add(this.dtp_empDOJ);
            this.groupBox1.Controls.Add(this.dtp_empDOB);
            this.groupBox1.Controls.Add(this.cmb_empGender);
            this.groupBox1.Controls.Add(this.txt_empAddress);
            this.groupBox1.Controls.Add(this.txt_empContactNo);
            this.groupBox1.Controls.Add(this.txt_empMailId);
            this.groupBox1.Controls.Add(this.txt_empGovtId);
            this.groupBox1.Controls.Add(this.txt_empName);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(12, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(570, 482);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // btn_regEmployee
            // 
            this.btn_regEmployee.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btn_regEmployee.Location = new System.Drawing.Point(236, 440);
            this.btn_regEmployee.Name = "btn_regEmployee";
            this.btn_regEmployee.Size = new System.Drawing.Size(150, 30);
            this.btn_regEmployee.TabIndex = 29;
            this.btn_regEmployee.TabStop = false;
            this.btn_regEmployee.Text = "नोंदणी करा";
            this.btn_regEmployee.UseVisualStyleBackColor = true;
            // 
            // cmb_empSpouseName
            // 
            this.cmb_empSpouseName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_empSpouseName.FormattingEnabled = true;
            this.cmb_empSpouseName.Location = new System.Drawing.Point(160, 409);
            this.cmb_empSpouseName.Name = "cmb_empSpouseName";
            this.cmb_empSpouseName.Size = new System.Drawing.Size(373, 25);
            this.cmb_empSpouseName.TabIndex = 13;
            // 
            // cmb_empSpouseWorkStatus
            // 
            this.cmb_empSpouseWorkStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_empSpouseWorkStatus.FormattingEnabled = true;
            this.cmb_empSpouseWorkStatus.Items.AddRange(new object[] {
            "आहे",
            "नाही"});
            this.cmb_empSpouseWorkStatus.Location = new System.Drawing.Point(160, 378);
            this.cmb_empSpouseWorkStatus.Name = "cmb_empSpouseWorkStatus";
            this.cmb_empSpouseWorkStatus.Size = new System.Drawing.Size(172, 25);
            this.cmb_empSpouseWorkStatus.TabIndex = 10;
            // 
            // cmb_empJoiningCategory
            // 
            this.cmb_empJoiningCategory.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_empJoiningCategory.FormattingEnabled = true;
            this.cmb_empJoiningCategory.Items.AddRange(new object[] {
            "General",
            "OBC -  Other Backward Class (इतर मागास वर्ग)",
            "SC - SC & SC Converts to Buddhism (अनुसुचीत जाती)",
            "ST - ST including those living outside specified areas (अनुसुचीत जमाती)",
            "SBC - Special Backward Class (विशेष मागास प्रवर्ग)",
            "SEBC - Socialy And Educationally Backward Class (नागरिकता के सामाजिक और शैक्षिक र" +
                "ूप से पिछड़ा वर्ग)",
            "VJ - Vimukta Jati /Denotified Tribes (भटक्या जमाती अ)",
            "NT (B) - Nomadic Tribes B (भटक्या जमाती ब)",
            "NT (C) - Dhangar Nomadic Tribes C (भटक्या जमाती क)",
            "NT (D) - Vanjari Nomadic Tribes D (भटक्या जमाती ड)"});
            this.cmb_empJoiningCategory.Location = new System.Drawing.Point(160, 285);
            this.cmb_empJoiningCategory.Name = "cmb_empJoiningCategory";
            this.cmb_empJoiningCategory.Size = new System.Drawing.Size(373, 25);
            this.cmb_empJoiningCategory.TabIndex = 7;
            // 
            // cmb_empCategory
            // 
            this.cmb_empCategory.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_empCategory.FormattingEnabled = true;
            this.cmb_empCategory.Items.AddRange(new object[] {
            "General",
            "OBC -  Other Backward Class (इतर मागास वर्ग)",
            "SC - SC & SC Converts to Buddhism (अनुसुचीत जाती)",
            "ST - ST including those living outside specified areas (अनुसुचीत जमाती)",
            "SBC - Special Backward Class (विशेष मागास प्रवर्ग)",
            "SEBC - Socialy And Educationally Backward Class (नागरिकता के सामाजिक और शैक्षिक र" +
                "ूप से पिछड़ा वर्ग)",
            "VJ - Vimukta Jati /Denotified Tribes (भटक्या जमाती अ)",
            "NT (B) - Nomadic Tribes B (भटक्या जमाती ब)",
            "NT (C) - Dhangar Nomadic Tribes C (भटक्या जमाती क)",
            "NT (D) - Vanjari Nomadic Tribes D (भटक्या जमाती ड)"});
            this.cmb_empCategory.Location = new System.Drawing.Point(160, 254);
            this.cmb_empCategory.Name = "cmb_empCategory";
            this.cmb_empCategory.Size = new System.Drawing.Size(373, 25);
            this.cmb_empCategory.TabIndex = 6;
            // 
            // cmb_empOfficeType
            // 
            this.cmb_empOfficeType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_empOfficeType.FormattingEnabled = true;
            this.cmb_empOfficeType.Items.AddRange(new object[] {
            "शासकीय",
            "खाजगी"});
            this.cmb_empOfficeType.Location = new System.Drawing.Point(160, 347);
            this.cmb_empOfficeType.Name = "cmb_empOfficeType";
            this.cmb_empOfficeType.Size = new System.Drawing.Size(172, 25);
            this.cmb_empOfficeType.TabIndex = 9;
            // 
            // txt_empEducation
            // 
            this.txt_empEducation.Location = new System.Drawing.Point(160, 316);
            this.txt_empEducation.Name = "txt_empEducation";
            this.txt_empEducation.Size = new System.Drawing.Size(373, 25);
            this.txt_empEducation.TabIndex = 8;
            // 
            // dtp_empDOJ
            // 
            this.dtp_empDOJ.CustomFormat = "yyyy-MM-dd";
            this.dtp_empDOJ.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtp_empDOJ.Location = new System.Drawing.Point(409, 378);
            this.dtp_empDOJ.Name = "dtp_empDOJ";
            this.dtp_empDOJ.Size = new System.Drawing.Size(124, 25);
            this.dtp_empDOJ.TabIndex = 12;
            // 
            // dtp_empDOB
            // 
            this.dtp_empDOB.CustomFormat = "yyyy-MM-dd";
            this.dtp_empDOB.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtp_empDOB.Location = new System.Drawing.Point(409, 347);
            this.dtp_empDOB.Name = "dtp_empDOB";
            this.dtp_empDOB.Size = new System.Drawing.Size(124, 25);
            this.dtp_empDOB.TabIndex = 11;
            // 
            // cmb_empGender
            // 
            this.cmb_empGender.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_empGender.FormattingEnabled = true;
            this.cmb_empGender.Items.AddRange(new object[] {
            "पुरुष",
            "स्त्री",
            "इतर"});
            this.cmb_empGender.Location = new System.Drawing.Point(160, 223);
            this.cmb_empGender.Name = "cmb_empGender";
            this.cmb_empGender.Size = new System.Drawing.Size(172, 25);
            this.cmb_empGender.TabIndex = 5;
            // 
            // txt_empAddress
            // 
            this.txt_empAddress.Location = new System.Drawing.Point(160, 154);
            this.txt_empAddress.Multiline = true;
            this.txt_empAddress.Name = "txt_empAddress";
            this.txt_empAddress.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txt_empAddress.Size = new System.Drawing.Size(373, 63);
            this.txt_empAddress.TabIndex = 4;
            // 
            // txt_empContactNo
            // 
            this.txt_empContactNo.Location = new System.Drawing.Point(160, 123);
            this.txt_empContactNo.Name = "txt_empContactNo";
            this.txt_empContactNo.Size = new System.Drawing.Size(373, 25);
            this.txt_empContactNo.TabIndex = 3;
            // 
            // txt_empMailId
            // 
            this.txt_empMailId.Location = new System.Drawing.Point(160, 92);
            this.txt_empMailId.Name = "txt_empMailId";
            this.txt_empMailId.Size = new System.Drawing.Size(373, 25);
            this.txt_empMailId.TabIndex = 2;
            // 
            // txt_empGovtId
            // 
            this.txt_empGovtId.Location = new System.Drawing.Point(160, 61);
            this.txt_empGovtId.Name = "txt_empGovtId";
            this.txt_empGovtId.Size = new System.Drawing.Size(373, 25);
            this.txt_empGovtId.TabIndex = 1;
            // 
            // txt_empName
            // 
            this.txt_empName.Location = new System.Drawing.Point(160, 30);
            this.txt_empName.Name = "txt_empName";
            this.txt_empName.Size = new System.Drawing.Size(373, 25);
            this.txt_empName.TabIndex = 0;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(57, 350);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(97, 17);
            this.label14.TabIndex = 13;
            this.label14.Text = "कार्यालयाचा प्रकार";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(19, 412);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(135, 17);
            this.label13.TabIndex = 12;
            this.label13.Text = "असल्यास जोडीदाराचे नाव";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(17, 381);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(137, 17);
            this.label12.TabIndex = 11;
            this.label12.Text = "जोडीदार सेवेत आहे काय?";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(58, 257);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(96, 17);
            this.label11.TabIndex = 10;
            this.label11.Text = "कर्मचा-याचा प्रवर्ग";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(114, 319);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(40, 17);
            this.label10.TabIndex = 9;
            this.label10.Text = "शिक्षण";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(337, 375);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(74, 34);
            this.label9.TabIndex = 8;
            this.label9.Text = "प्रथम नियुक्ती\r\nदिनांक";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(126, 226);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(28, 17);
            this.label8.TabIndex = 7;
            this.label8.Text = "लिंग";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(338, 350);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(63, 17);
            this.label7.TabIndex = 6;
            this.label7.Text = "जन्मदिनांक";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(95, 157);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(59, 17);
            this.label6.TabIndex = 5;
            this.label6.Text = "संपुर्ण पत्ता";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(80, 126);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(74, 17);
            this.label5.TabIndex = 4;
            this.label5.Text = "संपर्क क्रमांक";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(81, 288);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(73, 17);
            this.label4.TabIndex = 3;
            this.label4.Text = "नियुक्ती प्रवर्ग";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(79, 95);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(75, 17);
            this.label3.TabIndex = 2;
            this.label3.Text = "ईमेल आय डी";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(60, 64);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(94, 17);
            this.label2.TabIndex = 1;
            this.label2.Text = "शासकीय आय डी";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(35, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(119, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "कर्मचा-याचे संपुर्ण नाव";
            // 
            // frmRegEmp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(594, 496);
            this.Controls.Add(this.groupBox1);
            this.DoubleBuffered = true;
            this.Font = new System.Drawing.Font("Segoe UI", 9.75F);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmRegEmp";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "कर्मचारी नोंदणी";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.DateTimePicker dtp_empDOJ;
        private System.Windows.Forms.DateTimePicker dtp_empDOB;
        private System.Windows.Forms.ComboBox cmb_empGender;
        private System.Windows.Forms.TextBox txt_empAddress;
        private System.Windows.Forms.TextBox txt_empContactNo;
        private System.Windows.Forms.TextBox txt_empMailId;
        private System.Windows.Forms.TextBox txt_empGovtId;
        private System.Windows.Forms.TextBox txt_empName;
        private System.Windows.Forms.ComboBox cmb_empSpouseName;
        private System.Windows.Forms.ComboBox cmb_empSpouseWorkStatus;
        private System.Windows.Forms.ComboBox cmb_empJoiningCategory;
        private System.Windows.Forms.ComboBox cmb_empCategory;
        private System.Windows.Forms.ComboBox cmb_empOfficeType;
        private System.Windows.Forms.TextBox txt_empEducation;
        private System.Windows.Forms.Button btn_regEmployee;
    }
}